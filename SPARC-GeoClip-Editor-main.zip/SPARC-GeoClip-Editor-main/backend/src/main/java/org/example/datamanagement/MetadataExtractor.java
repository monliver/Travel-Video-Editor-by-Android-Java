package org.example.datamanagement;

import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.drew.metadata.exif.GpsDirectory;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;

import java.util.HashMap;
import java.util.Map;

public class MetadataExtractor {
    public Map<String, String> extractPhotoMetadata(Metadata metadata) {
        Map<String, String> data = new HashMap<>();

        // Extract EXIF data
        ExifSubIFDDirectory directory = metadata.getFirstDirectoryOfType(ExifSubIFDDirectory.class);
        if (directory != null) {
            data.put("Date/Time", directory.getString(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL));
        }

        // Extract GPS data
        GpsDirectory gpsDirectory = metadata.getFirstDirectoryOfType(GpsDirectory.class);
        if (gpsDirectory != null) {
            data.put("Latitude", gpsDirectory.getGeoLocation().getLatitude() + "");
            data.put("Longitude", gpsDirectory.getGeoLocation().getLongitude() + "");
        }

        return data;
    }

    public Map<String, String> extractVideoMetadata(FFmpegProbeResult probeResult) {
        Map<String, String> data = new HashMap<>();

        // Extract creation time from the format tags
        if (probeResult.format.tags != null) {
            data.put("Date/Time", probeResult.format.tags.get("creation_time"));
        }

        // Extract GPS data if available
        if (probeResult.format.tags != null && probeResult.format.tags.containsKey("location")) {
            String location = probeResult.format.tags.get("location");
            if (location != null && location.startsWith("+")) {
                // Parse GPS coordinates from location tag (assuming +lat+long/ format)
                String[] parts = location.split("\\+");
                if (parts.length == 3) {
                    data.put("Latitude", parts[1]);
                    data.put("Longitude", parts[2]);
                }
            }
        }

        return data;
    }
}
