package org.example.datamanagement;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.drew.metadata.exif.GpsDirectory;

import java.io.File;
import java.io.IOException;


public class PhotoReader {
    public Metadata extractMetadata(String filePath) throws IOException {
        File file = new File(filePath);
        return ImageMetadataReader.readMetadata(file);
    }
}
