package org.example.datamanagement;

import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;

import java.io.IOException;

public class VideoReader {

    private final FFmpeg ffmpeg;

    public VideoReader() throws IOException {
        this.ffmpeg = new FFmpeg("/path/to/ffmpeg"); // Make sure FFmpeg is installed and the path is correct
    }

    public FFmpegProbeResult extractMetadata(String filePath) throws IOException {
        return ffmpeg.probe(filePath);
    }
}
