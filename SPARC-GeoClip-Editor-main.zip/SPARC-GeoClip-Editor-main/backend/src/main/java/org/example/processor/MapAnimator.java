package org.example.processor;

public class MapAnimator {
}
