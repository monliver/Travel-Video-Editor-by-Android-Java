package org.example.ui;

public class UserInterface {
}
