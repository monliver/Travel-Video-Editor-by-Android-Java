plugins {
    id("java")
    kotlin("jvm")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.10.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")

    //add dependency for photo metadata extraction
    implementation("com.drewnoakes:metadata-extractor:2.18.0")
    //add dependency for video metadata extraction

    //(todo: 1 venerable: code injection)
    implementation("net.bramp.ffmpeg:ffmpeg:0.8.0")
    implementation(kotlin("stdlib-jdk8"))
}

tasks.test {
    useJUnitPlatform()
}
kotlin {
    jvmToolchain(21)
}